import React from "react";
import { Link } from "react-router-dom";
import { motion } from "framer-motion";
import { Button } from "@/components/ui/button";
import { ArrowLeft } from "lucide-react";

export const PostHeader = ({ post, ytId }) => (
  <motion.div
    initial={{ opacity: 0, y: 12 }}
    animate={{ opacity: 1, y: 0 }}
    transition={{ duration: 0.35 }}
    className="flex flex-wrap items-center justify-between gap-2"
  >
    <Link to="/blog">
      <Button variant="outline" className="border-2">
        <ArrowLeft className="mr-2 h-4 w-4" /> Back
      </Button>
    </Link>

    {ytId && (
      <a
        href={`https://www.youtube.com/watch?v=${ytId}`}
        target="_blank"
        rel="noreferrer"
      >
        <Button className="border-2 bg-white! hover:text-gray-500!">
          Open Video
        </Button>
      </a>
    )}
  </motion.div>
);
