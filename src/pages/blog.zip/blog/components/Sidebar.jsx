import React from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Link } from "react-router-dom";

export const Sidebar = ({ post, more }) => (
  <aside className="min-w-0 space-y-4 lg:sticky lg:top-6 h-fit">
    <Card className="border-border bg-background">
      <CardContent className="p-5">
        <div className="text-xs font-black uppercase tracking-widest text-muted-foreground">
          Contents
        </div>
        <div className="mt-4 grid gap-2">
          {(post.sections || []).map((s) => (
            <a
              key={s.id}
              href={`#${s.id}`}
              className="rounded-xl border border-border bg-background px-3 py-2 text-sm font-semibold text-muted-foreground hover:bg-accent hover:text-foreground transition"
            >
              {s.label}
            </a>
          ))}
          {!post.sections?.length && (
            <div className="mt-3 text-xs text-muted-foreground">
              (Belum ada daftar isi. Tambah <code>sections</code> di{" "}
              <code>posts.js</code>.)
            </div>
          )}
        </div>
      </CardContent>
    </Card>

    <Card className="border-border bg-background">
      <CardContent className="p-5">
        <div className="text-xs font-black uppercase tracking-widest text-muted-foreground">
          More from this blog
        </div>
        <div className="mt-4 space-y-3">
          {more.map((p) => (
            <Link
              key={p.slug}
              to={`/blog/${p.slug}`}
              className="block rounded-xl border border-border bg-background px-3 py-3 hover:bg-accent/40 transition"
            >
              <div className="text-sm font-black leading-snug line-clamp-2">
                {p.title}
              </div>
              <div className="mt-1 text-xs text-muted-foreground">
                {p.tag} • {p.readTime}
              </div>
            </Link>
          ))}
        </div>
      </CardContent>
    </Card>
  </aside>
);
