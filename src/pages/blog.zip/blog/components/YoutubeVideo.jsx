import React from "react";
import { Youtube, Link as LinkIcon } from "lucide-react";

export const YoutubeVideo = ({ ytId }) =>
  ytId ? (
    <div className="mt-4 overflow-hidden rounded-2xl border border-border bg-background">
      <div className="flex items-center justify-between gap-3 px-4 py-3 border-b border-border bg-accent/30">
        <div className="inline-flex items-center gap-2 text-sm font-black">
          <Youtube className="h-5 w-5" /> Cuplikan YouTube
        </div>
        <a
          href={`https://www.youtube.com/watch?v=${ytId}`}
          target="_blank"
          rel="noreferrer"
          className="inline-flex items-center gap-2 text-xs font-bold text-primary hover:underline"
        >
          <LinkIcon className="h-4 w-4" /> buka
        </a>
      </div>
      <div className="aspect-video">
        <iframe
          className="h-full w-full"
          src={`https://www.youtube.com/embed/${ytId}`}
          title="YouTube video"
          allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
          allowFullScreen
        />
      </div>
    </div>
  ) : (
    <div className="mt-4 rounded-2xl border border-border bg-accent/20 p-4 text-sm text-muted-foreground">
      <b>Belum ada video.</b> Isi <code>youtube</code> di post ini.
    </div>
  );
