import React from "react";
import { Card, CardContent } from "@/components/ui/card";
import { ArticleProse } from "./ArticleProse";
import { YoutubeVideo } from "./YoutubeVideo";

export const PostContent = ({ post, ytId }) => (
  <div className="min-w-0">
    <Card className="overflow-hidden border-border bg-background">
      <div className="relative">
        <img
          src={post.cover}
          alt={post.title}
          className="h-[260px] w-full object-cover"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-background via-background/40 to-transparent" />
        <div className="absolute bottom-0 left-0 right-0 p-6">
          <div className="flex flex-wrap items-center gap-2 text-xs text-muted-foreground">
            <span className="inline-flex items-center gap-2 rounded-full border border-border bg-background/40 px-3 py-1 font-semibold backdrop-blur">
              {post.tag}
            </span>
            <span>{post.readTime}</span>
            <span>•</span>
            <span>{post.date}</span>
          </div>
          <h1 className="mt-3 text-3xl md:text-4xl font-black tracking-tight">
            {post.title}
          </h1>
          <p className="mt-2 text-sm text-muted-foreground max-w-2xl">
            {post.excerpt}
          </p>
        </div>
      </div>

      <CardContent className="p-6 md:p-10">
        <div className="mx-auto w-full max-w-[760px]">
          <ArticleProse post={post} ytId={ytId} />
        </div>
      </CardContent>
    </Card>
  </div>
);
