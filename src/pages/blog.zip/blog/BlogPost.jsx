import React, { useMemo } from "react";
import { Link, useParams, Navigate } from "react-router-dom";
import { motion } from "framer-motion";
import { BLOG_POSTS } from "./posts";

import { PostHeader } from "./components/PostHeader";
import { PostContent } from "./components/PostContent";
import { Sidebar } from "./components/Sidebar";

const getYouTubeId = (input) => {
  if (!input) return "";
  if (/^[a-zA-Z0-9_-]{11}$/.test(input)) return input;
  try {
    const url = new URL(input);
    if (url.hostname.includes("youtu.be")) return url.pathname.replace("/", "");
    const v = url.searchParams.get("v");
    if (v) return v;
    const parts = url.pathname.split("/").filter(Boolean);
    const embedIndex = parts.indexOf("embed");
    if (embedIndex !== -1 && parts[embedIndex + 1])
      return parts[embedIndex + 1];
    return "";
  } catch {
    return "";
  }
};

export const BlogPost = () => {
  const { slug } = useParams();
  const post = useMemo(() => BLOG_POSTS.find((p) => p.slug === slug), [slug]);
  if (!post) return <Navigate to="/blog" replace />;

  const ytId = getYouTubeId(post.youtube);
  const more = BLOG_POSTS.filter((p) => p.slug !== post.slug).slice(0, 3);

  return (
    <div className="w-full">
      <div className="mx-auto w-full max-w-[1320px] px-4 md:px-6 lg:px-8 min-[1920px]:ml-40 space-y-6">
        <PostHeader post={post} ytId={ytId} />
        <div className="grid gap-6 lg:gap-8 lg:grid-cols-[minmax(0,1fr)_360px]">
          <PostContent post={post} ytId={ytId} />
          <Sidebar post={post} more={more} />
        </div>
      </div>
    </div>
  );
};
