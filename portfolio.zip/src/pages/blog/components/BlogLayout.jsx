// src/pages/blog/components/BlogLayout.jsx
import React from "react";

export const BlogLayout = ({ title = "Blog", subtitle, children }) => {
  return (
    <div className="mr-5 ml-6 space-y-6 flex-1 min-w-0 w-full">
      <div className="space-y-2">
        <h1 className="text-4xl font-black tracking-tight">{title}</h1>
        {subtitle ? (
          <p className="text-sm text-muted-foreground">{subtitle}</p>
        ) : null}
      </div>

      {children}
    </div>
  );
};
